# Description of Basic algorithm


* Define the problem and is state space $s \in S$
    * gw=create_standard_grid()
* Specify a given policy to be evaluated $\pi(s), \, \forall s \in S$
* Initialize the value function $V(s) \in \mathbb{R}, \, \forall s \in S$
    * values = init_V(gw) 
